# Revision Tracker Android project

This Android WebView app packages the redesigned Revision Tracker HTML in `app/src/main/assets/index.html`.

Build a debug APK with Gradle 8.9 and Android Gradle Plugin 8.7.3:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The tracker stores its data in the app's local WebView storage. Export a backup from the app before uninstalling or clearing app data. This project uses a new Android application ID and signing identity; it is not guaranteed to install as an update over any earlier APK.
